package com.example.driverapp;


public class User {
    public String Name,email,num,pass;

    public User(){

    }

    public User(String Name,String email,String num,String pass){
        this.Name=Name;
        this.email=email;
this.pass=pass;
        this.num=num;
    }
}
